<?php

namespace App\Repositories\Mapper;

use App\RiskLog;

class RiskLogMapper
{

    public function map($objeto)
    {
        //TODO poner lo que corresponde aca
    }
}