<?php

namespace App\Repositories\Mapper;

use App\Roles;

class RolesMapper
{

    public function map($objeto)
    {
        //TODO poner lo que corresponde aca
    }
}