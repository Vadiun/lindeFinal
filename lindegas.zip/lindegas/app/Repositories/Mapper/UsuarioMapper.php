<?php
/**
 * Created by PhpStorm.
 * User: joaquin
 * Date: 11/10/17
 * Time: 20:58
 */

namespace App\Repositories\Mapper;


class UsuarioMapper
{
    public function map($objeto)
    {
        //TODO poner lo que corresponde aca
    }
}